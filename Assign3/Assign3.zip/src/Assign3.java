import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;

public class Assign3 {
    private static ArrayList<String> history = new ArrayList<>();
    private static String[] commands;
    private static String workingDirectory;
    private static boolean running = true;
    private static boolean isInteger;
    private static boolean validDirectory;

    void ptime() {

    }

    private static void printHistory() {
        System.out.println("--- Command History ---");
        for (int command = 0; command < history.size(); command++) {
            System.out.println((command + 1) + " : " + history.get(command));
        }
    }

    private static void saveToHistory(String command) {
        history.add(command);
    }

    private static void list() {
        File currentDirectory = new File(System.getProperty("user.dir"));
        File[] listOfFiles = currentDirectory.listFiles();
        String dirMarker;   //Marks a file as a directory
        String readMarker;  //Marks a file as readable
        String writeMarker; //Marks a file as writeable
        String exeMarker;   //Marks a file as executable

        System.out.println("");
        for (File file : listOfFiles) {
            Path myPath = Paths.get(String.valueOf(file));
            long bytes = 0;
            try {
                bytes = Files.size(myPath);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (file.isDirectory()) {
                dirMarker = "d";
            } else {
                dirMarker = "-";
            }
            if (file.canRead()) {
                readMarker = "r";
            } else {
                readMarker = "-";
            }
            if (file.canWrite()) {
                writeMarker = "w";
            } else {
                writeMarker = "-";
            }
            if (file.canExecute()) {
                exeMarker = "x";
            } else {
                exeMarker = "-";
            }
            String pattern = "MMM dd, yyyy HH:mm";
            String lastModified = new SimpleDateFormat(pattern).format(new Date(file.lastModified()));
            System.out.printf(dirMarker + readMarker + writeMarker + exeMarker + "%10s %20s %22s", bytes, lastModified, file.getName() + "\n");

        }
        System.out.println("");
    }

    private static void changeDirectory(File path) {
        String currentDir = System.getProperty("user.dir");
        File fileDir = new File(currentDir);
        if (path.isDirectory()) {
            //System.out.printf("The parent folder is: %s\n", fileDir.getParent());
            java.nio.file.Path proposed = java.nio.file.Paths.get(currentDir, path.toString());
            System.setProperty("user.dir", proposed.toString());
            //System.out.printf("Updated Directory: %s\n", System.getProperty("user.dir"));
            workingDirectory = System.getProperty("user.dir");
        } else {
            System.out.printf("Unable to change to directory '%s'\n", path);
        }
        if (path.toString().equals("..")) {

            System.setProperty("user.dir", fileDir.getParent());
            workingDirectory = System.getProperty("user.dir");
        }

//        ProcessBuilder pb = new ProcessBuilder("cmd", path.toString());
//        pb.directory(path);
//        pb.redirectInput(ProcessBuilder.Redirect.INHERIT);
//        pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);
//        try {
//            long start = System.currentTimeMillis();
//            Process p = pb.start();
//            System.out.println("Starting to wait");
//            p.waitFor();
//            long end = System.currentTimeMillis();
//            System.out.printf("Waited for %d milliseconds\n", end - start);
//        } catch (IOException | InterruptedException e) {
//            e.printStackTrace();
//        }
    }

    private static void changeToHomeDirectory() {
        File directory;     // Desired current working directory
        directory = new File(System.getProperty("user.home")).getAbsoluteFile();
        if (directory.exists() || directory.mkdirs()) {
            System.setProperty("user.dir", directory.getAbsolutePath());
        }
        workingDirectory = System.getProperty("user.dir");
    }

    private static void pipe(String command1, String command2) {  //user enters '|' as a command

    }

    private static boolean isBuiltInCommand(String command) {
        if (command.equals("Hi")) {
            return true;
        } else if (command.equals("Bla")) {
            return true;
        } else if (command.equals("history")) {
            return true;
        } else if (command.charAt(0) == '^') {   //command.equals("^ " + index)) {
            return true;
        } else if (command.equals("cd")) {
            return true;
        } else if (command.equals("ptime")) {
            return true;
        } else if (command.equals("|")) {
            return true;
        } else if (command.equals("list")) {
            return true;
        } else {
            return false;
        }
    }

    private static boolean runExternalCommand(String command) {
        ProcessBuilder pb = new ProcessBuilder("cmd.exe", command);
        pb.redirectErrorStream(true);
        try {
            System.out.println("Starting process to run external command...");
            Process p = pb.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
        //if (Process.getInputStream() == "'" + command + "' is not recognized as an internal or external command,
        //operable program or batch file.") { return false; }
    }

    private static void runPreviousCommand(int number) {  // ^ <number>
        String command = history.get(number - 1);

        if (command.charAt(0) == '^') {
            int index = command.charAt(2) - '0';
            runPreviousCommand(index);
        }
        else {
            runCommandFromHistory(number - 1);
        }
    }

    private static void runCommandFromHistory(int cmnd) {
        if (history.get(cmnd).equals("history")) {
            printHistory();
        } else if (history.get(cmnd).equals("cd")) {
            int fileName = cmnd + 1;
            if (fileName < history.size()) {
                File path = new File(history.get(fileName));
                System.out.println("Is " + path + " a file?" + (path.isFile() ? " Yes" : " No"));
                System.out.println("Is " + path + " a directory?" + (path.isDirectory() ? " Yes" : " No"));
                System.out.println("Files in the " + path + " directory: " + Arrays.toString(path.listFiles()));
                if (path.isDirectory()) {
                    changeDirectory(path);
                    validDirectory = true;
                } else if (isBuiltInCommand(path.toString())) {
                    changeToHomeDirectory();
                } else {
                    System.out.println("The system cannot find the path specified.");
                }
            } else {
                changeToHomeDirectory();
            }
        } else if (history.get(cmnd).equals("|")) {
            System.out.println("Piping!");
            if (!"|".equals(commands[0])) {
                pipe(history.get(cmnd - 1), history.get(cmnd + 1));
                System.out.println("Piping " + history.get(cmnd - 1) + " through " + history.get(cmnd + 1) + "!");
            }
        } else if (history.get(cmnd).equals("list")) {
            list();
        } else if (history.get(cmnd).equals("pTime")) {
            System.out.println("Time");
        } else if (history.get(cmnd).equals("^")) {
            int index = Integer.parseInt(history.get(cmnd + 1));
            if (index >= 1 && index <= history.size()) {  //bounds checking for history index
                runPreviousCommand(index);
            } else {
                System.out.println("Invalid index");
            }
        }
    }

    private static void runCommand(int command) {
        switch (commands[command]) {
            case "history":
                saveToHistory(commands[command]);
                printHistory();
                break;
            case "cd":
                int fileName = command + 1;
                if (fileName < commands.length) {
                    File path = new File(commands[fileName]);
//                    System.out.println("Is " + path + " a file?" + (path.isFile() ? " Yes" : " No"));
//                    System.out.println("Is " + path + " a directory?" + (path.isDirectory() ? " Yes" : " No"));
//                    System.out.println("Files in the " + path + " directory: " + Arrays.toString(path.listFiles()));
                    if (path.isDirectory()) {
                        changeDirectory(path);
                        saveToHistory(commands[command] + " " + commands[fileName]);
                        validDirectory = true;
                    } else if (isBuiltInCommand(path.toString())) {
                        changeToHomeDirectory();
                        saveToHistory(commands[command]);
                    } else {
                        System.out.println("The system cannot find the path specified.");
                    }
                } else {
                    changeToHomeDirectory();
                    saveToHistory(commands[command]);
                }
                break;
            case "|":
                System.out.println("Piping!");
                if (!"|".equals(commands[0])) {
                    pipe(commands[command - 1], commands[command + 1]);
                    System.out.println("Piping " + commands[command - 1] + " through " + commands[command + 1] + "!");
                    saveToHistory(commands[command]);
                }
                break;
            case "list":
                list();
                saveToHistory(commands[command]);
                break;
            case "ptime":
                System.out.println("Time");
                saveToHistory(commands[command]);
                break;
            case "^":
                if (command + 1 < commands.length) {
                    if (commands[command + 1].charAt(0) >= 48 && commands[command + 1].charAt(0) <= 57) {
                        isInteger = true;
                        for (int i = 0; i < commands[command + 1].length(); i++) {
                            if (commands[command + 1].charAt(i) < 48 || commands[command + 1].charAt(i) > 57) {
                                isInteger = false;
                            }
                        }
                        if (isInteger) {
                            int index = Integer.parseInt(commands[command + 1]);
                            if (index >= 1 && index <= history.size()) {  //bounds checking for history index
                                runPreviousCommand(index);
                                saveToHistory(commands[command] + " " + index);
                            } else {
                                System.out.println("Invalid index");
                            }
                        }
                    } else {
                        System.out.println("Invalid index");
                    }
                } else {
                    System.out.println("Syntax Error: ^ must also include a number and be in the form ^ <number>.");
                }
                break;
            case "exit":
                System.out.println("Goodbye.");
                running = false;
                break;
            default:
                if (!validDirectory && !isInteger) {
                    if (!runExternalCommand(commands[command])) {
                        System.out.printf("Invalid command: %s. \n", commands[command]);
                    }
                }
                break;
        }
    }

    public static void main(String[] args) {
        workingDirectory = System.getProperty("user.dir");

        Scanner in = new Scanner(System.in);

        while (running) {
            validDirectory = false;
            isInteger = false;      //Used for indicating if the index selected for ^ <index> is an integer

            String prompt = "[" + workingDirectory + "]: ";
            System.out.print(prompt);

            String input = in.nextLine();
            commands = input.split(" ");

            for (int command = 0; command < commands.length; command++) {
                runCommand(command);
            }
        }
    }
}

